#!/bin/sh
while true; do echo `date`; sleep 5; done
